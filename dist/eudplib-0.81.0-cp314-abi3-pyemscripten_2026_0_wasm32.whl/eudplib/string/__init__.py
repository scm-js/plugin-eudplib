# Copyright 2014 by trgk.
# All rights reserved.
# This file is part of EUD python library (eudplib),
# and is released under "MIT License Agreement". Please see the LICENSE
# file that should have been included as part of this package.

from .cpprint import (
    FixedText,
    PColor,
    PName,
    f_cpstr_print,
    f_eprintln,
    f_gettextptr,
    f_raise_CCMU,
)
from .cpstr import GetMapStringAddr
from .cputf8 import f_cp949_to_utf8_cpy
from .eudprint import f_dbstr_print
from .fmtprint import f_eprintAll, f_eprintf, f_sprintf, f_sprintf_cp
from .locale import LocalLocale
from .parse import f_parse
from .pname import IsPName, SetPName, SetPNamef
from .strall import DisplayTextAll, DisplayTextAllAt, f_printAll, f_printAllAt
from .strbuffer import (
    DisplayTextAt,
    GetGlobalStringBuffer,
    StringBuffer,
    f_printAt,
    f_println,
    f_simpleprint,
)
from .strcommon import epd2s, hptr, ptr2s
from .strfunc import f_strcmp, f_strcpy, f_strlen, f_strlen_epd, f_strnstr
from .tblprint import (
    GetTBLAddr,
    f_eprintln2,
    f_settbl,
    f_settbl2,
    f_settblf,
    f_settblf2,
)
from .texteffect import TextFX_FadeIn, TextFX_FadeOut, TextFX_Remove, TextFX_SetTimer

__all__ = [
    "DisplayTextAll",
    "DisplayTextAllAt",
    "DisplayTextAt",
    "FixedText",
    "GetGlobalStringBuffer",
    "GetMapStringAddr",
    "GetTBLAddr",
    "IsPName",
    "LocalLocale",
    "PColor",
    "PName",
    "SetPName",
    "SetPNamef",
    "StringBuffer",
    "TextFX_FadeIn",
    "TextFX_FadeOut",
    "TextFX_Remove",
    "TextFX_SetTimer",
    "epd2s",
    "f_cp949_to_utf8_cpy",
    "f_cpstr_print",
    "f_dbstr_print",
    "f_eprintAll",
    "f_eprintf",
    "f_eprintln",
    "f_eprintln2",
    "f_gettextptr",
    "f_parse",
    "f_printAll",
    "f_printAllAt",
    "f_printAt",
    "f_println",
    "f_raise_CCMU",
    "f_settbl",
    "f_settbl2",
    "f_settblf",
    "f_settblf2",
    "f_simpleprint",
    "f_sprintf",
    "f_sprintf_cp",
    "f_strcmp",
    "f_strcpy",
    "f_strlen",
    "f_strlen_epd",
    "f_strnstr",
    "hptr",
    "ptr2s",
]
